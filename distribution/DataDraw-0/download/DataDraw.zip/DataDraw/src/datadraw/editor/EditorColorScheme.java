package datadraw.editor;

public enum EditorColorScheme
{
	DARK, LIGHT
}
